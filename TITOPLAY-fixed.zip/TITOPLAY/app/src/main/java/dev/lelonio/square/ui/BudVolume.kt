package dev.lelonio.square.ui

import android.view.HapticFeedbackConstants
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import dev.lelonio.square.playback.AudioRoute
import dev.lelonio.square.playback.ChannelBalance

/** True while the music is going to headphones or earbuds (cable, Bluetooth, USB). */
@Composable
fun rememberHeadphonesConnected(): Boolean {
    val output by AudioRoute.current.collectAsState()
    return ChannelBalance.isHeadphones(output.kind)
}

/**
 * One earbud's volume, a strip along one edge of the cover: drag up or down
 * to set that side alone. The picture is `bud_left.jpg` / `bud_right.jpg` if
 * the app has them in its drawables, a drawn earbud otherwise.
 */
@Composable
fun BudVolumeStrip(right: Boolean, modifier: Modifier = Modifier) {
    val view = LocalView.current
    val context = LocalContext.current
    val level = if (right) ChannelBalance.right.floatValue else ChannelBalance.left.floatValue
    val resId = remember(right) {
        context.resources.getIdentifier(if (right) "bud_right" else "bud_left", "drawable", context.packageName)
    }
    Column(
        modifier = modifier
            .fillMaxHeight(0.5f)
            .width(64.dp)
            .pointerInput(right) {
                var current = 1f
                detectVerticalDragGestures(
                    onDragStart = {
                        current = if (right) ChannelBalance.right.floatValue else ChannelBalance.left.floatValue
                    },
                ) { change, dy ->
                    change.consume()
                    val next = (current - dy / (size.height * 0.6f)).coerceIn(0f, 1f)
                    if (kotlin.math.round(next * 20f) != kotlin.math.round(current * 20f)) {
                        view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    }
                    current = next
                    if (right) ChannelBalance.set(null, next) else ChannelBalance.set(next, null)
                }
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        if (resId != 0) {
            Image(
                painter = painterResource(resId),
                contentDescription = null,
                modifier = Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)),
                contentScale = ContentScale.Fit,
            )
        } else {
            Canvas(Modifier.size(38.dp)) {
                val w = size.width
                val h = size.height
                val ink = Color.White.copy(alpha = 0.92f)
                drawCircle(ink, radius = w * 0.27f, center = Offset(if (right) w * 0.42f else w * 0.58f, h * 0.30f))
                drawRoundRect(
                    ink,
                    topLeft = Offset(if (right) w * 0.52f else w * 0.30f, h * 0.30f),
                    size = Size(w * 0.18f, h * 0.62f),
                    cornerRadius = CornerRadius(w * 0.09f, w * 0.09f),
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier
                .width(7.dp)
                .height(130.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color.White.copy(alpha = 0.28f)),
            contentAlignment = Alignment.BottomCenter,
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(level.coerceIn(0.02f, 1f))
                    .background(Color.White.copy(alpha = 0.92f)),
            )
        }
    }
}
